package com.nagarro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcrudappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcrudappApplication.class, args);
	}

}
